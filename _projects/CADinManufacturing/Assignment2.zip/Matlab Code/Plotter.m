%Initializing a plot

plot3(0,0,0);
axis equal;
axis vis3d;
axis manual;
title WireframeMouse;
grid on;
ax = gca;
ax.XTick = 0:10:100;
ax.YTick = -50:10:50;
ax.ZTick = 0:10:100;
axis([0 100 -50 50 0 100 ]);

% data structure the predefined datastructure which contains information about-
data = load('data_structure.mat');
d = data.d;

% 'for' loop iterates through all the entries in the data structure
% case 1 refers to inputs required for a circle to be plotted
% case 2 refers to inputs required for a line to be plotted
% case 3 refers to inputs required for an ellipse to be plotted
% case 4 refers to inputs required for a ferguson curve to be plotted
% case 5 refers to inputs required for a bezier curve to be plotted

for i = 1:9
    
    switch d(i,2)
        case 1
            circle_xy([d(i,3),d(i,4),d(i,5)],d(i,6),[d(i,9),d(i,10)]);
        case 2
            line_3d([d(i,3),d(i,4),d(i,5)],[d(i,6),d(i,7),d(i,8)]);
        case 3
            ellipse_xy([d(i,3),d(i,4),d(i,5)],d(i,6),d(i,9),[d(i,12),d(i,13)]);
        case 4
            ferg([d(i,3),d(i,4),d(i,5)],[d(i,6),d(i,7),d(i,8)],[d(i,9),d(i,10),d(i,11)],[d(i,12),d(i,13),d(i,14)]);
        case 5
            bezi([d(i,3),d(i,4),d(i,5)],[d(i,6),d(i,7),d(i,8)],[d(i,9),d(i,10),d(i,11)],[d(i,12),d(i,13),d(i,14)]);
    end
end






