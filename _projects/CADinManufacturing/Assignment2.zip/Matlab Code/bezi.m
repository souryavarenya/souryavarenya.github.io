function [ R ] = bezi( pA ,pB,cA ,cB )
t = linspace(0,1);
B0 = zeros(length(t));
B1 = zeros(length(t));
B2 = zeros(length(t));
B3 = zeros(length(t));
R = zeros(3,100);
for i = 1:1:100
    % Defining Beizer Functions
    B0(i)= (1-t(i))^3;
    B1(i)= 3*t(i)*(1-t(i))^2;
    B2(i)= 3*t(i)^2*(1-t(i));
    B3(i)= t(i)^3;
    % Blending functions and points
    R(1,i) = pA(1)*B0(i)+cA(1)*B1(i)+cB(1)*B2(i)+pB(1)*B3(i);
    R(2,i) = pA(2)*B0(i)+cA(2)*B1(i)+cB(2)*B2(i)+pB(2)*B3(i);
    R(3,i) = pA(3)*B0(i)+cA(3)*B1(i)+cB(3)*B2(i)+pB(3)*B3(i);
end
    hold on;
    plot3(R(1,:),R(2,:),R(3,:));
end