function [ R ] = circle_xy( center, radius, p_range, ~ )

%   Here, we construct a circle parallel to XY plane, centered at (xc, yc,
%   zc)

t = linspace(p_range(1), p_range(2));

R = [ center(1)+radius*cos(t);
      center(2)+radius*sin(t);
      center(3)+0*t];
  
pA = [center(1)+radius*cos(p_range(1));
      center(2)+radius*sin(p_range(1));
      center(3)];
  
pB = [center(1)+radius*cos(p_range(2));
      center(2)+radius*sin(p_range(2));
      center(3)];

hold on;
plot3(R(1,:),R(2,:),R(3,:));


end

