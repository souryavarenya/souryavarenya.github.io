function [ R ] = ellipse_xy( center, a, b, p_range )

%   Here, we construct a ellipse parallel to XY plane, centered at (xc, yc,
%   zc)

t = linspace(p_range(1), p_range(2));

R = [ center(1)+b*cos(t);
      center(2)+a*sin(t);
      center(3)+0*t];
  
hold on;
plot3(R(1,:),R(2,:),R(3,:));

end

