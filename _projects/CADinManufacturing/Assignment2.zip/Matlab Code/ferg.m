function [ R ] = ferg( pA ,pB, tA,tB )
t = linspace(0,1);
H0 = zeros(length(t));
H1 = zeros(length(t));
H2 = zeros(length(t));
H3 = zeros(length(t));
R = zeros(3,100);
for i = 1:1:100
    H0(i)= 2*t(i)^3-3*t(i)^2+1;
    H1(i)= -2*t(i)^3+3*t(i)^2;
    H2(i)= t(i)^3-2*t(i)^2+t(i);
    H3(i)= t(i)^3-t(i)^2;
    
    R(1,i) = pA(1)*H0(i)+pB(1)*H1(i)+tA(1)*H2(i)+tB(1)*H3(i);
    R(2,i) = pA(2)*H0(i)+pB(2)*H1(i)+tA(2)*H2(i)+tB(2)*H3(i);
    R(3,i) = pA(3)*H0(i)+pB(3)*H1(i)+tA(3)*H2(i)+tB(3)*H3(i);
end
    hold on;
    plot3(R(1,:),R(2,:),R(3,:));
end