function [ R ] = line_3d( pA , pB, ~, ~ )

% A simple weighted average of each of the points to define a line
t = linspace(0,1);
R = zeros(3,100);

R(1,:) = (1-t)*pA(1) + t*pB(1);
R(2,:) = (1-t)*pA(2) + t*pB(2);
R(3,:) = (1-t)*pA(3) + t*pB(3);

hold on;
plot3(R(1,:),R(2,:),R(3,:));

end

