function [tc,tp]= TC(R,l,uv) %%function define
for i=1:size(uv,1)
    g = bezier(uv(i,1),uv(i,2));
    pts(:,i)=g(1:3);
    nrm(:,i)=g(4:6);
    NM(i) = norm(nrm(:,i));
    N1(:,i)=nrm(:,i)/NM(i); %% unit vectors in the direction of normal
    N2(:,i)=N1(:,i)*R; %% vectors in th direction of normal
    tc(:,i)=N2(:,i)+pts(:,i); %% finding tool center
    N4(:,i)=N1(:,i)*(R+l); %% another
    tp(:,i)=N4(:,i)+pts(:,i); %% tool end points
end
end