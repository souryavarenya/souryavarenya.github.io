function [] = animate(dir)
    % setting up axes
    ax = axes('XLim',[-30 90],'YLim',[-30 90],'ZLim',[0 120]);
    view(3)
    grid off
    axis on
    pbaspect([1 1 1])

    %% Bezier Surface Plot
    % We will use symbolic matrix multiplications to create parametric
    % equations of the surface and plot using _fsurf_ function.
    syms u v 
    U = [(1-u)^3, 3*u*(1-u)^2, 3*(u^2)*(1-u), u^3];
    Px =[0 -5 -7 0; 12 13 14 12; 28 29 28  29; 40 43 37 40];
    Py =[0 18 32 50; 0 17 31 55; 1 15 28 45; 0 18 32 50];
    Pz =[0 5 7 -3; -5 -3 10 5; 4 3 0 -7; 1 -1 5 0];
    V = [(1-v)^3; 3*v*(1-v)^2; 3*(v^2)*(1-v); v^3];

    x = U*Px*V;
    y = U*Py*V;
    z = U*Pz*V;
    h2 = fsurf(x, y, z, [0 1 0 1], 'EdgeColor','none','FaceColor',[0.72 0.45 0.2]);

    %% Geometriical Primitives
    % Here we'll define primitives for constructing the tool
    [x,y,z] = cylinder;
    [xs,ys,zs] = sphere(20);
    [xc,yc,zc] = cylinder([0,1]);

    % The generation of tool happens here
    h(1) = surface(2.5*x,2.5*y,20*z,'FaceColor',[0.1 0.1 0.1],'EdgeColor','none');
    h(2) = surface(2.5*xs,2.5*ys,2.5*zs,'FaceColor',[0.1 0.1 0.1],'EdgeColor','none');
    h(3) = surface(8*x,8*y,5*z+20,'FaceColor',[0.1 0.1 0.1],'EdgeColor','none');
    h(4) = surface(8*xc,8*yc,0.001*z+20,'FaceColor',[0.1 0.1 0.1],'EdgeColor','none');
    h(5) = surface(8*xc,8*yc,0.001*z+25,'FaceColor',[0.1 0.1 0.1],'EdgeColor','none');

    h3 = surface(50*xs+20,50*ys+25,50*zs+10,'FaceColor','none','EdgeColor','none');

    %% Initialization for animations

    % We are achieving animations using transformations, reducing computation
    % time by a huge amount

    t1 = hgtransform('Parent',ax);
    t2 = hgtransform('Parent',ax);
    t3 = hgtransform('Parent',ax);
    set(h,'Parent',t1)
    set(h2,'Parent',t2)
    set(h3,'Parent',t3)

    % Initializing Canvas
    pbaspect([1 1 1])
    camlight(-42,28)
    grid off
    axis off

    % Loading the data file consisting of cutter location and orientation for animation
    load(dir);

    %----- DEBUGGING STEP - IRRELEVANT ---------
    %hold on
    %line(tp(1,:),tp(2,:),tp(3,:));
    %line(tc(1,:),tc(2,:),tc(3,:));
    %----- DEBUGGING STEP - IRRELEVANT ---------

    % Path for trailing the tool contact point and angles 
    tr = 1.25*tc - 0.25*tp;
    for i = 1:size(tc,2)
        cy(i) = pi/2 - acos((tp(1,i)-tc(1,i))/10);
        cx(i) = acos((tp(2,i)-tc(2,i))/10) - pi/2;
    end

    %delay before the animation begins
    pause(10)

    %% Animating the path
    % This is the main loop where each frame is generated

    for r = 1:length(cx)
        Rx = makehgtform('xrotate',cx(r));
        Ry = makehgtform('yrotate',cy(r));
        %Toff = makehgtform('translate',[0 0 -2.5]);
        Txy = makehgtform('translate',tc(:,r)');
        set(t1,'Matrix',Txy*Rx*Ry)
        if r ~= 1   
            hold on 
            line([tr(1,r-1),tr(1,r)],[tr(2,r-1),tr(2,r)],[tr(3,r-1),tr(3,r)]);
            %%% ,'Color',[0.72 0.45 0.2],'LineWidth',6 
        end
        drawnow
        camorbit(0.5,0.005)

    end
end
