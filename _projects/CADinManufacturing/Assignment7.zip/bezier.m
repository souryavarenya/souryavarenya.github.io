function[XN] = bezier(u,v)    
Px=[0 -5 -7 0;
    12 13 14 12;
    28 29 28  29;
    40 43 37 40;
    ];
Py=[0 18 32 50;
    0 17 31 55;
    1 15 28 45;
    0 18 32 50;
    ];
Pz=[0 5 7 -3;
    -5 -3 10 5;
    4 3 0 -7;
    1 -1 5 0];

U=[(1-u)^3 3*u*(1-u)^2 3*u^2*(1-u) u^3];
V=[(1-v)^3; 3*v*(1-v)^2; 3*v^2*(1-v); v^3];

x=U*Px*V;
y=U*Py*V;
z=U*Pz*V;

dU=[-3*(1-u)^2 -6*u*(1-u)+3*(1-u)^2 6*u*(1-u)-3*u^2 3*u^2];
dV=[-3*(1-v)^2; -6*v*(1-v)+3*(1-v)^2; 6*v*(1-v)-3*v^2; 3*v^2];
tux=dU*Px*V;
tuy=dU*Py*V;
tuz=dU*Pz*V;

tu=[tux tuy tuz];

tvx=U*Px*dV;
tvy=U*Py*dV;
tvz=U*Pz*dV;

tv=[tvx tvy tvz];

n = cross(tu,tv);
N=n./norm(n);

XN=[x y z N];
end


