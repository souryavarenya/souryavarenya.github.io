function [dir] = generate_tool_path(d,tol,l)
    v=0;          % starting point for slice
    i=0;
    uv  =[;];
    while v<1
        u = stepsize(v,tol);        %+ve/-ve u direction,input is v out put is u
        dv = sstep(v,d,tol);
        if mod(i,2) == 1
            u = fliplr(u);
        end
        uv_new(:,1) = u;                   %for a combined array of u and v
        uv_new(:,2) = v*ones(size(u,1),1); %append uv_new to existing uv
        uv = [uv; uv_new];
        uv_new = [;];
    %     [tc,tp] = TC(d,l,uv);
    %     pts = [pts tc];
    %     nrm = [nrm tp];
        v = v+dv;  %move to next slice
        i = i+1;
    end
    [tc,tp] = TC(d/2,l,uv);
    % plot3(tc(1,:),tc(2,:),tc(3,:))
    dir = sprintf('%d.mat',tol);
    save(dir)
end