clear;

d = 5; %tool diameter
tol = 2; %tolerance
l = 10; %reference point inside tool

% Generating tool path and saving directory of points
dir = generate_tool_path(d,tol,l); 

% Animating tool path using diectory of points
animate(dir);
