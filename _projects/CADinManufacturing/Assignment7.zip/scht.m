function y=scht(s,t1,t2,d)
% splitting for getting scallop height with corrections
n=4;
t=t1:(t2-t1)/(n-1):t2;
% initializing
pts=zeros(3,n);
nrm=zeros(3,n);
% getting points and normal
for i=1:n
    g = bezier(s,t(i));
    pts(:,i)=g(1:3);
    nrm(:,i)=g(4:6);
end
% scallop height without corrections
l=norm(pts(:,1)-pts(:,n));
h=d/2-(abs((d/2)^2-(l/2)^2))^0.5;
max=h;
% for i=2:n-1
%     % convex or concave
%     a=pts(:,i)-pts(:,1);
%     b=pts(:,n)-pts(:,1);
%     r1=a-dot(a,b)*b/norm(b);
%     % concave or convex and adding the necessary value
%     if dot(r1,nrm(:,i))>0
%         delt=h-norm(r1);
%     else
%         delt=h+norm(r1);
%     end
%     % getting the maximum value
%     if delt>max
%         max=delt;
%     end
% end
% return scallop height
y=max;
end
