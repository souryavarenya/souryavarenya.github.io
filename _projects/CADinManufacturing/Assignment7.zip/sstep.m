function y=sstep(t,d,tol)
% initial step value assumption
dt=(2*((d/2)^2-(d/2-tol)^2)^0.5)/50;
% splitting for scalop height for differnt s positions 
n=4;
s=0:1/(n-1):1;
% initilization
scallop=0;
% loop till the required tolerance is acheived
while(1)
    t2=t+dt;
    % end step
    if t2>1
        t2=1;
        dt=t2-t;
    end
    % get the maximum scallop for diffrent s values
    for i=1:n
        scallop=max(scallop,scht(s(i),t,t2,d));
    end
    % if conditon for break
    if scallop<tol
        break;
    end
    % decrease the dt value if req. tol. is not acheived
    dt=0.75*dt;
    scallop=0;
end
% return t value for next step
y = t2-t;
end