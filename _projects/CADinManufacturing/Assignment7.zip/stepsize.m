function [u]=stepsize(v,t)
    u(1)=0;
    i=1;             
        while 1
          du=.1; %first guess del u
          d=10*t*ones(1,3);
            while max(d)>t 
                u(i+1)=u(i)+du; %get new u
                p=u(i):du/4:u(i+1);% partition the gap
                for k=2:length(p)-1
                    d(1,k-1)=norm(cross((pts(p(k),v)-pts(u(i),v)),(pts(u(i+1),v)-pts(u(i),v))))/norm(pts(u(i+1),v)-pts(u(i),v));% calculate heights
                end
                du=0.75*du;% update delta u if tol is exceeded
            end
            if u(i+1)>=1
                u(i+1)=1; % break if the limit of the suurface is reached
                break;
            end
            i=i+1;
        end       
end

function pts = pts(u,v)
    ptss = bezier(u,v);
    pts = ptss(1:3);
end