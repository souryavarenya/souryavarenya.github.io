function [m_list] =  contour(z,p,t,vt)
    int_facet_slice  = zeros(size(t,1),1);
    %Finding the relevant facets at given slice height
     for k = 1:1:size(t,1)
        vtxnum = vt{k,2};      
        if (p(vtxnum(3),3) < z && z< p(vtxnum(1),3))
        int_facet_slice(1,k) = k;
        else int_facet_slice(1,k)= 0;   
        end
     end
    int_facet_slice( ~any(int_facet_slice,2), : ) = []; % removes zeros in the facet slice 
    int_facet_slice( :, ~any(int_facet_slice,1) ) = []; 
    % Finding Intersection Points in the facets
    int_points = [];

    %intersectionpoints = find_intersection(int_points,int_facet_slice, );
    for m = 1:1: size(int_facet_slice,2)
         vtxnumm = vt{int_facet_slice(m),2};
         fxx = [p(vtxnumm(1),1) p(vtxnumm(2),1) p(vtxnumm(3),1)];
         fyy = [p(vtxnumm(1),2) p(vtxnumm(2),2) p(vtxnumm(3),2)];
         fzz = [p(vtxnumm(1),3) p(vtxnumm(2),3) p(vtxnumm(3),3)];
         lamd = [ (z-fzz(2))/(fzz(1)-fzz(2)) (z-fzz(3))/(fzz(2) - fzz(3)) (z - fzz(3)) / (fzz(1)-fzz(3))] ;
         fox = [ (1-lamd(1)).*fxx(2)+lamd(1).*fxx(1) (1-lamd(2)).*fxx(3)+lamd(2).*fxx(2) (1-lamd(3)).*fxx(3)+lamd(3).*fxx(1)];
         foy = [ (1-lamd(1)).*fyy(2)+lamd(1).*fyy(1) (1-lamd(2)).*fyy(3)+lamd(2).*fyy(2) (1-lamd(3)).*fyy(3)+lamd(3).*fyy(1)];
         dum = [];
     for n = 1:1:3    
         if (lamd(n)>=0 && lamd(n)<=1 )         
         dum(n) =n;
         end
     end
    dum( ~any(dum,2), : ) = []; % removes zeros 
    dum( :, ~any(dum,1) ) = []; 
          int_points(2*m-1,1)= fox(dum(1)) ; int_points(2*m-1,2)= foy(dum(1)) ;  
          int_points(2*m-1,3)= z ; int_points(2*m-1,4)= int_facet_slice(m) ;
          int_points(2*m,1)= fox(dum(2)) ; int_points(2*m,2)= foy(dum(2)) ;  
          int_points(2*m,3)= z ; int_points(2*m,4)= int_facet_slice(m) ;
    end

    m_list = zeros(length(int_points)/2+1,3);
    prev_index = 1;
    % Ordering the facet intersection points to form contour
    for p = 1:length(int_points)/2

        m_list(p,:) = int_points(prev_index,1:3);
        xindex = find(int_points(:,1)==int_points(prev_index,1));
        yindex = find(int_points(:,2)==int_points(prev_index,2));
        findex = setdiff(intersect(xindex,yindex),prev_index);
        prev_index = findex+(-1)^(1+findex);

    end
    m_list(length(int_points)/2+1,:) = m_list(1,:);
    plot3(m_list(:,1),m_list(:,2),m_list(:,3)); hold on;

end 
