function [ vt,h,p,t ] = initialize( filename )
% t is an array containing vertex numbers 'p'
% p is an array containing vertices coordinates
% tnorm is the facet normal
[p,t,tnorm] = import_stl_fast(filename,1);

    %% Sorting Vertices based on z co-ordinates in each facet
    for i = 1:1:size(t,1)
        vt{i,1} = [t(i,1) t(i,2) t(i,3)];
        v{i,1} = [p(t(i,1),3) p(t(i,2),3) p(t(i,3),3)]; 
        vz = v{i}; 
    
        if  (vz(1)> vz(2) && vz(2)>= vz(3))
            vt{i,2} = [t(i,1) t(i,2) t(i,3)];
        elseif (vz(1)> vz(2) && vz(2)< vz(3))
            vt{i,2} = [t(i,1) t(i,3) t(i,2)];
        elseif (vz(2)> vz(3) && vz(3)>= vz(1))
            vt{i,2} = [t(i,2) t(i,3) t(i,1)];   
        elseif (vz(2)> vz(3) && vz(3)< vz(1))
            vt{i,2} = [t(i,2) t(i,1) t(i,3)];
        elseif (vz(3)> vz(1) && vz(1)>= vz(2))
            vt{i,2} = [t(i,3) t(i,1) t(i,2)];   
        elseif (vz(3)> vz(1) && vz(1)< vz(2))
            vt{i,2} = [t(i,3) t(i,2) t(i,1)];
        elseif (vz(3) == vz(1) && vz(1)== vz(2))
            vt{i,2} = [t(i,1) t(i,2) t(i,3)];
        end
        % vt{i,2} is the sorted array
    end
    % h gives maximum height of the body from vertex coordinates
    h = range(p(:,3));
end

