clear

filename = 'Assignment8_ASCII.stl'; 
num_slices = 20;

[vt,h,p,t] = initialize(filename);
slice(vt,h,num_slices,p,t);