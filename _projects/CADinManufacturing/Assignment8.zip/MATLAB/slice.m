function [] = slice(vt,h,num_slices,p,t)
    % Iterating through each slice height
    for zc = 1:num_slices
        
        z = zc*h/num_slices;
        % m_list is a list of ordered contour points
        m_list = contour(z,p,t,vt);
        hold on;
        plot3(m_list(:,1),m_list(:,2),m_list(:,3),'blue')
    
    end
    % Setting up the axes aspect ratios
    plot3(0,0,0);
    axis equal;
    axis vis3d;
    axis manual;
    title '3D-Body-Slicing';
    grid on;
    ax = gca;

end